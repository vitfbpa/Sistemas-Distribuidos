public class Main {
    public static void main(String[] args) {
        Thread pares = new MinhaThread(0, 20);
        Thread impares = new MinhaThread(1, 19);
        pares.setName("Pares");
        impares.setName("Impares");
        pares.start();
        impares.start();
    }
}
class MinhaThread extends Thread {
    int inicio, fim;
    MinhaThread(int inicio, int fim) { this.inicio = inicio; this.fim = fim; }
    public void run() {
        StringBuilder sb = new StringBuilder(Thread.currentThread().getName() + " ");
        for (int i = inicio; i <= fim; i += 2) sb.append(i).append(" ");
        System.out.println(sb.toString());
    }
}
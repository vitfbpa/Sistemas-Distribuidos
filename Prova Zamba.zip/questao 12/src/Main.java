public class Main {
    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new MinhaThread("Vicenzo de Souza");
        Thread t2 = new MinhaThread("Vicenzo de Souza");
        Thread t3 = new MinhaThread("Vicenzo de Souza");

        t1.start(); t1.join(); Thread.sleep(2000);
        t2.start(); t2.join(); Thread.sleep(2000);
        t3.start(); t3.join();
    }
}
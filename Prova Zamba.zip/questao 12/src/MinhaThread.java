class MinhaThread extends Thread {
    MinhaThread(String nome) { super(nome); }
    public void run() { System.out.println(getName()); }
}
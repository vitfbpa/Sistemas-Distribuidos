class MinhaThread extends Thread {
    static int contador = 0;      // compartilhado (sem lock)
    int vezes;
    MinhaThread(String nome, int vezes) { super(nome); this.vezes = vezes; }

    public void run() {
        for (int i = 0; i < vezes; i++) {
            int antes = contador;
            contador = antes + 1;
            System.out.println(getName() + " leu " + antes + " gravou " + contador);
            Thread.yield();
        }
    }
}
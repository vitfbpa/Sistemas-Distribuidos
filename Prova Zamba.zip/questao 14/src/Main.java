public class Main {
    public static void main(String[] args) throws InterruptedException {
        int n = 5;
        Thread t1 = new MinhaThread("T1", n);
        Thread t2 = new MinhaThread("T2", n);
        t1.start(); t2.start();
        t1.join();  t2.join();
        System.out.println("Final " + MinhaThread.contador);
    }
}
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class MinhaThread extends Thread {
    static int contador = 0;
    static Lock lock = new ReentrantLock();
    int vezes;
    MinhaThread(String nome, int vezes) { super(nome); this.vezes = vezes; }
    public void run() {
        for (int i = 0; i < vezes; i++) {
            lock.lock();
            try {
                contador++;
                System.out.println(getName() + " -> " + contador);
            } finally { lock.unlock(); }
        }
    }
}
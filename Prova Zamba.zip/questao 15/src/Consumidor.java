import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Consumidor extends Thread {
    private final BlockingQueue<Integer> fila;
    Consumidor(BlockingQueue<Integer> f) { this.fila = f; }
    public void run() {
        try {
            while (true) {
                int v = fila.take();
                if (v == -1) break;
                System.out.println("CONSUMIDOR " + v);
            }
        } catch (InterruptedException ignored) {}
    }
}
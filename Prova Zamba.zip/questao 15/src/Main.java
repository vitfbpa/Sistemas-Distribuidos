import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        BlockingQueue<Integer> fila = new ArrayBlockingQueue<>(5);
        Thread p = new Produtor(fila);
        Thread c = new Consumidor(fila);
        p.start(); c.start();
        p.join();  c.join();
    }
}
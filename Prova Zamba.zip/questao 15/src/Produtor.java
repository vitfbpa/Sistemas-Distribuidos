import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Produtor extends Thread {
    private final BlockingQueue<Integer> fila;
    Produtor(BlockingQueue<Integer> f) { this.fila = f; }
    public void run() {
        try {
            for (int i = 1; i <= 10; i++) { fila.put(i); System.out.println("PRODUTOR " + i); }
            fila.put(-1); //SOMENTE PRA ENCERRAR
        } catch (InterruptedException ignored) {}
    }
}
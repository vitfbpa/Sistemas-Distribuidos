import java.util.concurrent.BlockingQueue;

class Processo extends Thread {
    int id, L = 0;
    BlockingQueue<Integer> in, out;
    Processo(int id, BlockingQueue<Integer> in, BlockingQueue<Integer> out) { this.id = id; this.in = in; this.out = out; }
    void local() { L++; System.out.println("P" + id + " evento local  L=" + L); }
    void send() throws InterruptedException { L++; out.put(L); System.out.println("P" + id + " ENVIA MENSAGEM  L=" + L); }
    void recv() throws InterruptedException { int t = in.take(); L = Math.max(L, t) + 1; System.out.println("P" + id + " RECEBE MENSAGEM  L=" + L); }

    public void run() {
        try {
            if (id == 1) { local(); send(); recv(); local(); }
            else { recv(); local(); send(); }
        } catch (InterruptedException ignored) {}
    }
}
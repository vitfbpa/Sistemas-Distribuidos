import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class SimulacaoDistribuida {
    public static void main(String[] args) throws InterruptedException {
        BlockingQueue<Integer> q12 = new LinkedBlockingQueue<>();
        BlockingQueue<Integer> q21 = new LinkedBlockingQueue<>();
        Thread A = new Processo(1, q21, q12);
        Thread B = new Processo(2, q12, q21);
        A.start(); B.start();
        A.join();  B.join();
    }
}
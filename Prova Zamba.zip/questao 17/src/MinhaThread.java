class MinhaThread extends Thread {
    private final int[] nums;
    private int resultado;
    MinhaThread(int[] nums) { this.nums = nums; }
    public void run() {
        for (int n : nums) {
            resultado += n;
            System.out.println("+" + n + " -> soma parcial " + resultado);
        }
    }
    public int getResultado() { return resultado; }
}
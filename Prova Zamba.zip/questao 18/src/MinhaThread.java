import java.util.concurrent.CyclicBarrier;

class MinhaThread extends Thread {
    static CyclicBarrier barreira = new CyclicBarrier(4, () -> System.out.println("Todas concluíram a fase 1"));
    int id;
    MinhaThread(int id) { this.id = id; }
    public void run() {
        try {
            System.out.println("T" + id + " fase 1");
            Thread.sleep(200);
            barreira.await();
            System.out.println("T" + id + " fase 2");
        } catch (Exception ignored) {}
    }
}
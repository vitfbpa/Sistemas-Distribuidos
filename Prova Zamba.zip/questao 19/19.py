# Deadlock simples com duas threads e dois recursos
import threading, time

A = threading.Lock()
B = threading.Lock()

def t1():
    A.acquire(); print("t1 pegou A")
    time.sleep(0.1)
    print("t1 tenta B"); B.acquire()  # fica preso aqui
    B.release(); A.release()

def t2():
    B.acquire(); print("t2 pegou B")
    time.sleep(0.1)
    print("t2 tenta A"); A.acquire()  # e aqui
    A.release(); B.release()

x = threading.Thread(target=t1, daemon=True)
y = threading.Thread(target=t2, daemon=True)
x.start(); y.start()
x.join(1); y.join(1)

if x.is_alive() and y.is_alive():
    print("Finalizado")


# Para evitar deadlock, imponha uma ordem global de travas e faça com que todas as threads sempre adquiram e liberem os recursos nessa mesma ordem.

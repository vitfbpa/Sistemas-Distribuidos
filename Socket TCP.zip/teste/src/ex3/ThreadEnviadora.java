/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex3;

import java.net.Socket;
import java.util.Scanner;

public class ThreadEnviadora extends Thread {

    Socket socket;

    public ThreadEnviadora(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("Digite: ");
            while (true) {
                String mensagem = scanner.nextLine();
                Comunicador.enviaMensagem(socket, mensagem); //envia uma mensagem pela rede
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}